package com.edu.yog.hibernate.releationship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateReleationshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
