package com.edu.yog.hibernate.releationship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

@SpringBootApplication()
public class HibernateReleationshipApplication{

	public static void main(String[] args) {
		SpringApplication.run(HibernateReleationshipApplication.class, args);
		
		
	}
	
}

