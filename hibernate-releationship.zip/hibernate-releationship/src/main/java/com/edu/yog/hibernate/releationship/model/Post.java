package com.edu.yog.hibernate.releationship.model;

public class Post {

}
