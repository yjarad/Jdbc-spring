package com.edu.yog.hibernate.releationship.dao;

public class PostService {

}
